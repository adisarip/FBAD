
#define IN
#define OUT

// TODO Check image resolution of dslr and update it here.
#define MAX_IMAGE_WIDTH  1920 // no of columns
#define MAX_IMAGE_HEIGHT 1080 // no of rows

typedef unsigned int  uint;
typedef unsigned char uchar;
